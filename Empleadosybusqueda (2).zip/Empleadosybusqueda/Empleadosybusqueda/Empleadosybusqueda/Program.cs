﻿using Empleadosybusqueda;
using Empleadosybusqueda.Empleadosybusqueda;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//1. Pensar que la implementacion no debe tener demasiada logica, concentrar la logica en las clases Empleado y Empresa.

namespace Empleadosybusqueda
{
    public class Program
    {
        static void Main(string[] args)
        {
            Empresa miEmpresa = new Empresa();
            miEmpresa.AgregarEmpleado(new Empleado(101, "Carlos Gómez", 850000));
            miEmpresa.AgregarEmpleado(new Empleado(102, "Ana Martínez", 920000));
            miEmpresa.AgregarEmpleado(new Empleado(103, "Lucas Rossi", 780000));
            int legajoBuscado = 99;

            Console.WriteLine($"Buscando empleado con legajo {legajoBuscado}...");
            Console.WriteLine(miEmpresa.BuscarPorLegajo(legajoBuscado));

           

            Console.WriteLine("\n--- EMPLEADO CON MAYOR SUELDO ---");
            Empleado mayorSueldo = miEmpresa.BuscarEmpleadoConMayorSueldo();
            if (mayorSueldo != null)
            {
                Console.WriteLine(mayorSueldo.MostrarDatos());
            }
            Console.WriteLine("\nPresione cualquier tecla para salir...");
            Console.ReadKey();


        }
    }
}
