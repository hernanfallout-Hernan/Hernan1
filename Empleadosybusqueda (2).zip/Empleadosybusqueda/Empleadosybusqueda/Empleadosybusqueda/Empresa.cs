﻿using Empleadosybusqueda;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Empleadosybusqueda
{
    namespace Empleadosybusqueda
    {
        internal class Empresa
        {

            private List<Empleado> empleados;
            EmpleadoPersistidor persistidor;



            public List<Empleado> Empleados
            {
                get { return empleados; }
            }


            public Empresa()
            {
                empleados = new List<Empleado>();
                persistidor = new EmpleadoPersistidor();
            }


            public void AgregarEmpleado(Empleado emp)
            {
                //verificar que el empleado no exista en la lista antes de agregarlo llamar a 2


                //llamar a metodo que sea guardar ademas de agregarlo a la lista
                if (emp != null)
                {
                    empleados.Add(emp);
                }
            }

            public string BuscarPorLegajo2(int leg)
            {
                Empleado emple = persistidor.BuscarPorLegajo(leg);
                if (emple != null)
                {
                    return emple.MostrarDatos();
                }
                else
                {
                    return "Empleado no encontrado";
                }
            }
            public Empleado BuscarPorLegajo(int legajo)
            {
                foreach (Empleado emp in empleados)
                {
                    if (emp.Legajo == legajo)
                    {
                        return emp;
                    }


                }
                return null;
            }





            public void MostrarDatosEmpleadoMaxSueldo()
            {
                Empleado empleado = persistidor.BuscarEmpleadoConMayorSueldo();

                if (empleado != null)
                {
                    empleado.MostrarDatos();
                }
                else
                {
                    Console.WriteLine("No hay empleados cargados en el sistema.");
                }


                int cantidad = persistidor.ContarEmpleadosSueldoMayorA(400000m);
                Console.WriteLine($"Empleados con sueldo mayor a 400.000: {cantidad}");
            }

            public Empleado BuscarEmpleadoConMayorSueldo()
            {
                if (empleados.Count == 0)
                {
                    return null;
                }

                Empleado mayor = empleados[0];
                foreach (Empleado emp in empleados)
                {
                    if (emp.Sueldo > mayor.Sueldo)
                    {
                        mayor = emp;
                    }
                }
                return mayor;
            }
        }
    }
}