﻿using Empleadosybusqueda;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Empleadosybusqueda
{
    /*Tarea: 
    1-Agregar el método de buscar al empleado con mayor sueldo.En la clase empresa se debe devolver el método MostrarDatos del empleado con mayor sueldo de todos los empleados.
    2-Agregar el método de cuantos empleados tienen un sueldo mayor a 400000. Se podría volver a usar ExecuteScalar como hicimos en clase.
    3-Realizar la implementación de los anteriores en el main
    4-Revisar si el codigo tiene alguna redundancia que se pueda resolver llamando a metodos primitivos*/ //confeccione mapear empleados para no ser redundante e insertar Legajo,Nombre y Sueldo varias veces
    internal class EmpleadoPersistidor
    {
        private readonly string connectionString = "Data Source=Marisa\\SQLEXPRESS;Initial Catalog=EMPRESA;Integrated Security=True";
        private SqlConnection connection;
        private readonly string tabla = "EMPLEADO";
        public EmpleadoPersistidor()
        {
            connection = new SqlConnection(connectionString);
        }
        private Empleado MapearEmpleado(SqlDataReader reader)
        {
            return new Empleado
            {
                Legajo = reader.GetInt32(reader.GetOrdinal("Legajo")),
                Nombre = reader.GetString(reader.GetOrdinal("Nombre")),
                Sueldo = reader.GetDecimal(reader.GetOrdinal("Sueldo"))
            };
        }
        public Empleado BuscarPorLegajo(int leg)
        {
            using (SqlCommand command = new SqlCommand($"SELECT * FROM {tabla} WHERE Legajo = @Legajo", connection))
            {
                command.Parameters.AddWithValue("@Legajo", leg);
                
                try
                {
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            
                                return MapearEmpleado(reader); 
                            }
                            return null;
                        }
                    }
            finally
                {
                    connection.Close();
                }
            }
        }
        // 2 agregar metodo de verificar si un empleado existe mediante la ejecucion de una consulta
        //que si ella devuelve 0 entonces sabemos que no existe el empleado buscado
        //si devuelve mas de 0 entonces sabemos que existe el empleado buscado
        public bool VerificarEmpleado(int emple)
        {
            using (SqlCommand command = new SqlCommand($"SELECT * FROM {tabla} WHERE Legajo = {emple}", connection))
            {
                try
                {
                    connection.Open();
                    int elemento = (int)command.ExecuteScalar();
                    return elemento > 0;
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        //2 metodo que de de alta a un empleado, un insert into la tabla empleado, con los datos del empleado que se le pase como parametro
        //

        public Empleado BuscarEmpleadoConMayorSueldo()
        {
            string query = $"SELECT * FROM {tabla} ORDER BY Sueldo DESC";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                try
                {
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return MapearEmpleado(reader); 
                        }
                        return null;
                    }
                }
                finally
                {
                    connection.Close();
                }
            }
        }


        public int ContarEmpleadosSueldoMayorA(decimal sueldoMinimo)
        {
           
            string query = $"SELECT COUNT(*) FROM {tabla} WHERE Sueldo > @Sueldo";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Sueldo", sueldoMinimo);

                try
                {
                    connection.Open();

                   
                    object resultado = command.ExecuteScalar();

                    if (resultado != null && resultado != DBNull.Value)
                    {
                        return Convert.ToInt32(resultado);
                    }

                    return 0;
                }
                finally
                {
                    connection.Close();
                }
            }
        }
    }
}