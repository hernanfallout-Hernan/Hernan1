﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Ejercicio 1 – Empleados y búsqueda por legajo
Crear un programa para administrar empleados de una empresa.
•	Crear la clase Empleado con las propiedades Legajo (int), Nombre (string) y Sueldo (double).
•	Definir un constructor que reciba los tres datos y los asigne al objeto.
•	Agregar un método MostrarDatos() que muestre o devuelva la información del empleado. Elegir una sola alternativa y mantenerla de forma consistente.
•	Crear una clase Empresa que posea una List<Empleado>.*/

namespace Empleadosybusqueda
{
    public class Empleado
    {

        public int Legajo { get; set; }
        public string Nombre { get; set; }
        public decimal Sueldo { get; set; }

       
        public Empleado(int legajo, string nombre, decimal   sueldo)
        {
            Legajo = legajo;
            Nombre = nombre;
            Sueldo = sueldo;
        }
        public Empleado()
        {
            
        }

        public string MostrarDatos()
        {
            return $"Legajo: {Legajo} | Nombre: {Nombre} | Sueldo: ${Sueldo:N2}";
        }
    }
}
